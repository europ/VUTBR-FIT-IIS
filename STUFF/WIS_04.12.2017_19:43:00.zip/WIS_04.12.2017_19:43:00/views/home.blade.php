@extends('layouts.app')

@section('content')
        <div class="col-md-12">
            <div class="blank-slate-pf" color="red" id="">
                <div class="blank-slate-pf-icon">
                    <img src="/img/logo.svg" alt="Logo"/>
                </div>
                <h1>
                    <strong>
                        {{config('app.name')}}
                    </strong>
                </h1>
            </div>
        </div>

@endsection








