<a class="btn btn-default" href="{{ url()->previous() }}">
	Vrátit se zpět
</a>