@extends('layouts.app')

@section('content')

    <div class="col-md-12">
        <div class="blank-slate-pf">
            <h1>
                <strong>TODO</strong>
            </h1>
        </div>
    </div>

@endsection

