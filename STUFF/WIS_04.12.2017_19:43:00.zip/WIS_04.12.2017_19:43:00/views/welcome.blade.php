@extends('layouts.app')

@section('content')
    <div class="col-md-12">
        <hr/>
        <div class="blank-slate-pf " id="">
            <div class="blank-slate-pf-icon">
                <span class="pficon pficon pficon-add-circle-o"></span>
            </div>
            <h1>
                Empty State Title
            </h1>
            <p>
                Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
            </p>
            <p>
                Learn more about this <a href="#">on the documentation</a>.
            </p>
            <div class="blank-slate-pf-main-action">
                <button class="btn btn-primary btn-lg"> Main Action </button>
            </div>
            <div class="blank-slate-pf-secondary-action">
                <button class="btn btn-default"> Secondary Action </button> <button class="btn btn-default"> Secondary Action </button> <button class="btn btn-default"> Secondary Action </button>
            </div>
        </div>
    </div>

@endsection

@section('scripts')

@endsection