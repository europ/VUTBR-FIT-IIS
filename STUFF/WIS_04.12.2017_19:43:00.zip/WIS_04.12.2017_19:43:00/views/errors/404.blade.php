@extends('layouts.app')

@section('content')

    <div class="col-md-12">
        <div class="blank-slate-pf">
            <h1>
                <strong>404 Not Found</strong>
            </h1>
        </div>
    </div>

@endsection

